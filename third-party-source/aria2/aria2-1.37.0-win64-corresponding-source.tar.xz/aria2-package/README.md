# aria2 1.37.0 Win64 corresponding-source candidate

This package corresponds to the upstream Windows x64 executable distributed by Clear Download Manager with SHA-256 be2099c214f63a3cb4954b09a0becd6e2e34660b886d4c898d260febfe9d70c2. The hash matches aria2c.exe in the official aria2-1.37.0-win-64bit-build1.zip release asset. Upstream release tag release-1.37.0 resolves to commit 02f2d0d8472b3c38c29b4dba8c75ebd5fdd2899a.

The archive contains the official source tarball, all six static library source archives named by upstream README.mingw, the build recipe files from the same source commit, a build-input inventory, and readable license copies. The source tarball also contains the full project source tree and its bundled source dependencies.

## Build route documented upstream

From the source tree, upstream makerelease builds the release MinGW binaries using Dockerfile.mingw; set the target host to x86_64-w64-mingw32. The recipe uses mingw-config, which configures --without-openssl and enables c-ares, SQLite, Expat, zlib, GMP and libssh2. The Windows binary is statically linked to GMP 6.3.0, Expat 2.5.0, SQLite 3.43.1, zlib 1.3, c-ares 1.19.1 and libssh2 1.11.0. The source package includes those exact dependency archives and their SHA-256 values.

The recipe targets the same upstream source version and dependency versions, but is not claimed as a bit-for-bit rebuild: upstream Dockerfile uses a floating Ubuntu 22.04 image and unpinned apt packages, and its dependency downloads have no built-in checksum verification. The binary-to-source relationship is supported by the exact hash match to the official upstream release asset; no independent rebuild was performed.

## OpenSSL

The upstream Windows configuration explicitly uses --without-openssl; OpenSSL is not among the statically linked libraries listed for this build. The upstream source and distribution include the general LICENSE.OpenSSL notice, retained here with the original notice.

## License review

See licenses/ and LICENSE-INVENTORY.md. Distributor review remains pending; this package does not make a legal determination.
