# License inventory

These notices are copied from the exact upstream source archives included here unless noted.

- aria2: GPL-2.0-or-later; licenses/aria2-COPYING.txt. Upstream source also contains the per-file OpenSSL linking exception. The selected MinGW build configuration opts out of OpenSSL.
- wslay source bundled by aria2: notice in licenses/wslay-COPYING.txt.
- GMP 6.3.0: upstream dual license texts retained in licenses/gmp-COPYINGv3.txt and licenses/gmp-COPYING.LESSERv3.txt; original COPYING is retained as well.
- Expat 2.5.0: licenses/expat-COPYING.txt.
- SQLite 3.43.1: source header disclaims copyright and provides its blessing; the included source archive contains that exact notice.
- zlib 1.3: licenses/zlib-LICENSE.txt.
- c-ares 1.19.1: licenses/c-ares-LICENSE.md.
- libssh2 1.11.0: licenses/libssh2-COPYING.txt.
- OpenSSL: licenses/aria2-LICENSE.OpenSSL.txt is retained because it is present in upstream materials; the selected Windows configuration says --without-openssl, so it is not treated as a linked runtime dependency.

This inventory identifies notices and the build configuration. Human distributor review is still required.
